#!/usr/bin/perl -w

#Generate time buttons  for web animation
# Roux


$font = "Helvetica";
$size = 13;

@buttons = ("red","blue");

$start=-10;
$step=1;
$end=10;

#@times=[];



for (my $i=$start;$i<=$end;$i+=$step){
	$label = sprintf("%+dd",$i);
        print "$label\n";
	$labeldraw = sprintf("%4dd",$i);
	foreach $butt(@buttons) { system("convert -size 40x13 xc:white -stroke $butt -fill $butt -font $font -pointsize $size -gravity East -draw 'text 10,0 \"$labeldraw\"' $butt$label.png")};
        push(@times,"$label");
	

}

print "var times = new Array(\"", join('","', @times), "\");\n";


