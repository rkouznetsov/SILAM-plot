#!/usr/bin/perl -w

#Generate time buttons  for web animation
# Roux


$font = "Helvetica";
$size = 13;

@buttons = ("red","blue");

$start=1;
$step=1;
$end=240;

#@times=[];

foreach $butt(@buttons){
	#Play buttons
	system("convert -size 40x13 xc:white -stroke $butt -fill $butt -font $font -pointsize $size -draw 'text 0,12 \"PLAY\"' ${butt}PLAY.png");
	#Dummy buttons
	system("convert -size 40x2 xc:white -stroke $butt -fill $butt -draw 'ellipse 10,2 5,1 0,360' ${butt}dummy.png");
	system("convert -size 40x2 xc:white -stroke $butt -fill $butt -draw 'ellipse 13,2 8,1 0,360' ${butt}dummyl.png");
	system("convert -size 40x4 xc:white -stroke $butt -fill $butt -draw 'ellipse 13,2 5,1 0,360' ${butt}dummyt.png");

}

exit();
for (my $i=$start;$i<=$end;$i+=$step){
	$label = sprintf("+%dh",$i);
	print "$label\n";
        if ($i % 6 == 0){
	        foreach $butt(@buttons) { system("convert -size 40x13 xc:white -stroke $butt -fill $butt -font $font -pointsize $size -draw 'text 0,11 \"$label\"' $butt$label.png")};
		if ($i % 24 == 0){
                        push(@times,"$label");

		}else{
#	   		foreach $butt(@buttons) {system("cp ${butt}dummyl.png $butt$label.png")};
                        push(@times,"dummyl");
                        #                 push(@files,"picdummyl.png")
		}
	  } else {
#	    foreach $butt(@buttons) {system("cp ${butt}dummy.png $butt$label.png"); };
            push(@times,"dummy");
#            push(@files,"picdummy.png")
	}
	

}

print "var times = new Array(\"", join('","', @times), "\");\n";


