#!/usr/bin/perl -w

#Generate time lables for web animation
# Roux


# $font = "Helvetica";
# $size = 13;
# @buttons = ("red","blue");

$start=1;
$step=1;
$end=24;

#@times=[];



for (my $i=$start;$i<=$end;$i+=$step){
	$label = sprintf("+%dh",$i);
  if ($i % 6 == 0){
		if ($i % 24 == 0){
                        push(@times,"$label");
		}else{
                        push(@times,"$label");
                        #push(@times,"dummyl");
		}
	  } else {
            push(@times,"dummy");
	}
	

}

print "var times = new Array(\"", join('","', @times), "\");\n";


